define('plugins/notifications/tutorial/register', [
    'io.ox/core/extensions',
    'io.ox/core/notifications/subview',
    'io.ox/core/event'
], function (ext, Subview, Events) {

    'use strict';

    var counter = 0;

    var api = {
        get: function (data) {
            var result = {
                id: data.id,
                text: 'I am ' + data.id
            };
            return $.Deferred().resolve(result);
        },
        reset: function () {
            counter = 0;
            api.trigger('reset', { id: 'myNotification' + counter });
            counter++;
        }
    };

    Events.extend(api);

    ext.point('io.ox/core/notifications/tutorial/footer').extend({
        draw: function (baton) {
            this.append($('<button class="btn">').text('reset notifications')
                .on('click', function () {
                    api.reset();
                }),
                $('<button class="btn">').text('add notifications')
                .on('click', function () {
                    baton.view.addNotifications({ id: 'myNotification' + counter });
                    counter++;
                }));
        }
    });

    ext.point('io.ox/core/notifications/tutorial/item').extend({
        draw: function (baton) {
            var cid = _.cid(baton.model.attributes);

            this.attr('data-cid', cid).append($('<div>').text(baton.model.get('text')),
                $('<button class="btn">').text('remove notification').on('click', function () {
                    baton.view.removeNotifications(baton.model);
                }));
        }
    });

    ext.point('io.ox/core/notifications/register').extend({
        id: 'tutorialplugin',
        index: 1000,
        register: function () {
            var options = {
                    id: 'io.ox/tutorialplugin',
                    title: 'Test Notifications',
                    extensionPoints: {
                        item: 'io.ox/core/notifications/tutorial/item',
                        footer: 'io.ox/core/notifications/tutorial/footer'
                    },
                    autoOpen: true,
                    api: api,
                    apiEvents: {
                        reset: 'reset'
                    },
                    detailview: {
                        draw: function (obj) {
                            var node = $('<div>').append($('<div>').text('i am the tutorial detailview'),
                                $('<div>').text(obj.data.text));
                            return node;
                        }
                    },
                    specificDesktopNotification: function (model) {
                        return {
                            title: 'New tutorial notification',
                            body: model.get('text'),
                            icon: ''
                        };
                    }
                };
            new Subview(options);

            api.reset();
        }
    });

    return true;
});
